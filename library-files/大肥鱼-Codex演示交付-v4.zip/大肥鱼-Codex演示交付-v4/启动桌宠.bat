@echo off
chcp 65001 >nul
cd /d "%~dp0项目"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 launcher.py --desktop
) else (
  python launcher.py --desktop
)
if errorlevel 1 (
  echo 请确认安装 Python 3.10 或更新版本，并完整解压本包。
  pause
)
