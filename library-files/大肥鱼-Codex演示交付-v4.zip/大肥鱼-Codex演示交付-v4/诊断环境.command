#!/bin/sh
cd "$(dirname "$0")/项目" || exit 1
python3 doctor.py
